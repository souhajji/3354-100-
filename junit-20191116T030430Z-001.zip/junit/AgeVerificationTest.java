import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AgeVerificationTest 
{
	@BeforeClass
		public static void beforeClass() 
		{
			System.out.println("Before Class");
		}
	
	@Before
		public void before() 
		{
			System.out.println("Before Test Case");
		}
	
	@Test
		public void ageVerificationTest() 
		{
			System.out.println("Test");
			AgeVerification HW = new AgeVerification();
			assertEquals("Here is the test for AgeVerification", false,  HW.verifyAge(17));
			assertEquals("Here is the test for AgeVerification", true ,  HW.verifyAge(18));
			assertEquals("Here is the test for AgeVerification", true ,  HW.verifyAge(19));
		}
	
	@After
		public void After() 
		{
			System.out.println("After Test Case");
		}
	@AfterClass
		public static void AfterClass() 
		{
			System.out.println("After Class");
		}
	
}
