public class AgeVerification 
{
	public boolean verifyAge(int age) 
	{
		boolean isOlderThan18 = (age >= 18);
		return  isOlderThan18;
	}
}
